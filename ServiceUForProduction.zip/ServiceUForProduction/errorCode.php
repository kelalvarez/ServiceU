<!DOCTYPE html>
<?php
    include("DatabaseFunctions.php"); 
    include("functions.php");
?>


<?php 
    session_start();
    if (!isset($_SESSION["loginEmail"]))
    {
        header("location: index.php");
        exit();
    }
    else{
       $userEmail = $_SESSION["loginEmail"];
       if(checkVerification($userEmail)){
           header("location: services.php");
       }
    }   
    
    
    $invalidCode = 0;    
    if (isset($_POST['verifyCode'])) {
        $code = $_POST['verificationCode'];
        
        
        if (verifyCode($userEmail, $code)) {
            verifyAccount($userEmail);
            header("location: services.php"); 
        } else {
            $invalidCode = 1;
	}        
    }   
    
    
?>


<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ServiceU</title>

    <!-- Bootstrap Core CSS -->

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    
     <!--Customized CSS-->
    <link rel="stylesheet" href="css/mycss.css">

</head>

    
<body>

    <!-- Navigation Sidebar -->
    <?php include 'navigationbar.php' ?>

<div class="container">
<?php if($invalidCode == 1){ ?>    
    <div class="alert alert-danger fade in">
       <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
       <strong>Invalid!</strong> The verification code is invalid.
     </div> 
<?php } ?>    
    
    
<div class="well text-center" style="height: 100%;">

    <h3><strong>Verification Pending</strong></h3>
<div class="row">
<div class="col-md-10 col-lg-push-1">    
You have not verified your e-mail address. Please provide the code that was sent to your e-mail.
</div>
</div>
    <br>
    <div class="row">
        <div class="col-md-10 col-md-push-1">    
        <form id="verifiedCode" class="form-horizontal" action="#" name="verifyCode" method="POST">
            
            <input type="text" style="border: 1px solid gray;" name="verificationCode" placeholder="Enter your verification code">
            <br><br>
            <button name="verifyCode" class="btn btn-primary" type="submit">Verify</button>
        </form>        
        </div>
    </div>
</div>    
</div>
      







<!--------- NEED TO BE ADDED TO ALL DOCUMENT FROM HERE -------->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script src="js/bootbox.js"></script>
    <script src="js/bootbox.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


    <!-- Custom for project -->
    <script src="js/editProfileactions.js"></script>
    
     <!--Start online JSS first-->
    <script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
    <!--Bootstrap JSS-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <!--Customized JSS-->
    <script src="js/myjs.js"></script>
    
    <!--change active mode in the navbar-->
    <script> 
        $(".nav a").on("click", function(){
           $(".nav").find(".active").removeClass("active");
           $(this).parent().addClass("active");
        });
        
        
        $(document)  
        .on('show.bs.modal', '.modal', function(event) {
          $(this).appendTo($('body'));
        })
        .on('shown.bs.modal', '.modal.in', function(event) {
          setModalsAndBackdropsOrder();
        })
        .on('hidden.bs.modal', '.modal', function(event) {
          setModalsAndBackdropsOrder();
        });

        function setModalsAndBackdropsOrder() {  
          var modalZIndex = 1040;
          $('.modal.in').each(function(index) {
            var $modal = $(this);
            modalZIndex++;
            $modal.css('zIndex', modalZIndex);
            $modal.next('.modal-backdrop.in').addClass('hidden').css('zIndex', modalZIndex - 1);
        });
          $('.modal.in:visible:last').focus().next('.modal-backdrop.in').removeClass('hidden');
        }
        
    </script>

    
</body>
</html>
