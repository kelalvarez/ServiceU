<!DOCTYPE html>
<?php
    include("DatabaseFunctions.php"); 
    include("functions.php");
?>


<?php 
    session_start();
    if (!isset($_SESSION["loginEmail"]))
    {
        header("location: index.php");
        exit();
    }
    else{
       $userEmail = $_SESSION["loginEmail"];
    }   

    $noback = 0;
    
    
    if(isset($_GET['employeeEmail']) && isset($_GET['jobID']))
    {
        $employeeEmail = $_GET['employeeEmail'];
        $jobID = $_GET['jobID'];
        
        
        $is = isOwner($userEmail, $jobID);
        if($is == 0 ){
            header("location: errorAccess.php");
            exit();
        }
        
        $has = hasApplied($employeeEmail, $jobID);
        if($has == 0 ){
            header("location: errorAccess.php");
            exit();
        }
    }
    else if (isset($_GET['employeeEmail'])){
        $employeeEmail = $_GET['employeeEmail'];
        
        
        if($userEmail != $employeeEmail){
            header("location: errorAccess.php");
            exit();
        }
        else{
            $noback = 1;
        }
    }
    else{ 
        header("location: errorAccess.php");
        exit();
    }
            


?>


<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ServiceU</title>

    <!-- Bootstrap Core CSS -->

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

</head>

    
<body>

    <!-- Navigation Sidebar -->
    <?php include 'navigationbar.php' ?>

<div class="container">
    

<div class="well text-center">

    <h3><strong>User Review</strong></h3>
    
    <?php  if ($noback != 1){ ?>
    <a href="postComplete.php?jobID=<?php echo $jobID ?>">Go back to Post</a>
    <?php }?>
</div>    
    
<div class="row">
<div class="col-md-2">
<div class="col-sm-12 col-md-12 text-center">
    <strong><span class="text-center input-lg">
             Sort by
    </span></strong>
<div id="nav">                    
    <hr class="small">
    <a href="#" class="flip btn btn-sm btn-warning btn-block">
        <Strong>ALL</strong>
    </a>
    
    <a href="#" class="flip btn btn-sm btn-warning btn-block">
        <?php for($i = 0; $i < 5 ; $i++){ ?>
        <span class="glyphicon glyphicon-star"></span>
        <?php } ?>
    </a>
    
    <a href="#" class="flip btn btn-sm btn-warning btn-block">
        <?php for($i = 0; $i < 4 ; $i++){ ?>
        <span class="glyphicon glyphicon-star"></span>
        <?php } ?>
    </a>
    
    <a href="#" class="flip btn btn-sm btn-warning btn-block">
        <?php for($i = 0; $i < 3 ; $i++){ ?>
        <span class="glyphicon glyphicon-star"></span>
        <?php } ?>
    </a>
    
    <a href="#" class="flip btn btn-sm btn-warning btn-block">
        <?php for($i = 0; $i < 2 ; $i++){ ?>
        <span class="glyphicon glyphicon-star"></span>
        <?php } ?>
    </a>
    
    <a href="#" class="flip btn btn-sm btn-warning btn-block">
        <span class="glyphicon glyphicon-star"></span>
    </a>
</div>

             
       
</div>
                
                  
                  

    </div>
    <div class="col-md-10">

    <div class="well well-lg">    

                <!---
                <div class="col-lg-10 col-lg-offset-1">-->
 
            <div class="row">
                
                <div class="col-sm-10 col-lg-push-4">
                    <h1><span style="font-weight: bold">

<a href="viewmyprofile.php?userID=<?php echo getID($employeeEmail); ?>"><?php echo getFullName($employeeEmail); ?></a>
                            <br>                                
                    </span>
                    </h1>
                            <?php 
                                drawStars(getRate($employeeEmail));
                            ?>
                      
                    
                </div>
            </div>
<div class="parent">                
                <?php //include('completeReviews.php'); ?>
<div id="panel1" class="panel row">
            <span class="input-sm"><strong> </strong></span>
            <br>
            <!------ Review Section ------------->    
            <table class="table table-striped">
            <?php 

                $nroComments = getNroComments($employeeEmail);

                $result = getComments($employeeEmail);



                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr><td class="col-md-3">';
            ?>   

                    <?php        
                    echo "<strong>Overall Rating</strong>";
                    echo "<br>";
                    drawStars($row['stars']);
            ?>


            <?php        
                    echo "</td>";

                    echo "<td>";

                    $date = date_create( $row['entryDate']);
                    echo date_format($date, 'm/d/Y H:i');

                    echo "<br>By: ";
                    echo getFullName($row['senderID']);


                    echo "<br><br>";
                    echo $row['comment'];
                    echo "<br><br>";
                    echo "<strong>Would you recommend this service?</strong>";
                    echo "<br>";
                    isRecommended($row['recommend']);

                    echo "</td></tr>";
                }
                 if ( $nroComments == 0){
                    echo "No comments available";
                }

            ?>

            </table>


                <?php //} ?>
</div>

    <div id="panel2" class="panel row">
            <span class="input-sm"><strong></strong></span>
            <br>
            <!------ Review Section ------------->    
            <table class="table table-striped">
            <?php 
            $stars5Comments = getNroStarsComments($employeeEmail, 5);

                $result = getStarComments($employeeEmail, 5 );



                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr><td class="col-md-3">';
            ?>   

                    <?php        
                    echo "<strong>Overall Rating</strong>";
                    echo "<br>";
                    drawStars($row['stars']);
            ?>


            <?php        
                    echo "</td>";

                    echo "<td>";

                    $date = date_create( $row['entryDate']);
                    echo date_format($date, 'm/d/Y H:i');

                    echo "<br>By: ";
                    echo getFullName($row['senderID']);


                    echo "<br><br>";
                    echo $row['comment'];
                    echo "<br><br>";
                    echo "<strong>Would you recommend this service?</strong>";
                    echo "<br>";
                    isRecommended($row['recommend']);

                    echo "</td></tr>";
                }
                
                 if ( $stars5Comments == 0){
                    echo "No comments available";
                }

            ?>

            </table>

</div>

<div id="panel3" class="panel row">
            <span class="input-sm"><strong></strong></span>
            <br>
            <!------ Review Section ------------->    
            <table class="table table-striped">
            <?php 

                $stars4Comments = getNroStarsComments($employeeEmail, 4);

                $result = getStarComments($employeeEmail, 4);



                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr><td class="col-md-3">';
            ?>   

                    <?php        
                    echo "<strong>Overall Rating</strong>";
                    echo "<br>";
                    drawStars($row['stars']);
            ?>


            <?php        
                    echo "</td>";

                    echo "<td>";

                    $date = date_create( $row['entryDate']);
                    echo date_format($date, 'm/d/Y H:i');

                    echo "<br>By: ";
                    echo getFullName($row['senderID']);


                    echo "<br><br>";
                    echo $row['comment'];
                    echo "<br><br>";
                    echo "<strong>Would you recommend this service?</strong>";
                    echo "<br>";
                    isRecommended($row['recommend']);

                    echo "</td></tr>";
                }
                if ( $stars4Comments == 0){
                    echo "No comments available";
                }

            ?>

            </table>
</div>

<div id="panel4" class="panel row">
            <span class="input-sm"><strong> </strong></span>
            <br>
            <!------ Review Section ------------->    
            <table class="table table-striped">
            <?php 

                $stars3Comments = getNroStarsComments($employeeEmail, 3);
                $result = getStarComments($employeeEmail, 3);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr><td class="col-md-3">';
            ?>   

                    <?php        
                    echo "<strong>Overall Rating</strong>";
                    echo "<br>";
                    drawStars($row['stars']);
            ?>


            <?php        
                    echo "</td>";

                    echo "<td>";

                    $date = date_create( $row['entryDate']);
                    echo date_format($date, 'm/d/Y H:i');

                    echo "<br>By: ";
                    echo getFullName($row['senderID']);


                    echo "<br><br>";
                    echo $row['comment'];
                    echo "<br><br>";
                    echo "<strong>Would you recommend this service?</strong>";
                    echo "<br>";
                    isRecommended($row['recommend']);

                    echo "</td></tr>";
                }
                if ( $stars3Comments == 0){
                    echo "No comments available";
                }
                 

            ?>

            </table>
</div>
                
<div id="panel5" class="panel row">
            <span class="input-sm"><strong> </strong></span>
            <br>
            <!------ Review Section ------------->    
            <table class="table table-striped">
            <?php 

                $stars2Comments = getNroStarsComments($employeeEmail, 2);

                $result = getStarComments($employeeEmail, 2);



                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr><td class="col-md-3">';
            ?>   

                    <?php        
                    echo "<strong>Overall Rating</strong>";
                    echo "<br>";
                    drawStars($row['stars']);
            ?>


            <?php        
                    echo "</td>";

                    echo "<td>";

                    $date = date_create( $row['entryDate']);
                    echo date_format($date, 'm/d/Y H:i');

                    echo "<br>By: ";
                    echo getFullName($row['senderID']);


                    echo "<br><br>";
                    echo $row['comment'];
                    echo "<br><br>";
                    echo "<strong>Would you recommend this service?</strong>";
                    echo "<br>";
                    isRecommended($row['recommend']);

                    echo "</td></tr>";
                }
                 if ( $stars2Comments == 0){
                    echo "No comments available";
                }

            ?>

            </table>

</div>
                
<div id="panel6" class="panel row">
            <span class="input-sm"><strong> </strong></span>
            <br>
            <!------ Review Section ------------->    
            <table class="table table-striped">
            <?php 

                $stars1Comments = getNroStarsComments($employeeEmail, 1);
                $result = getStarComments($employeeEmail, 1);



                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr><td class="col-md-3">';
            ?>   

                    <?php        
                    echo "<strong>Overall Rating</strong>";
                    echo "<br>";
                    drawStars($row['stars']);
            ?>


            <?php        
                    echo "</td>";

                    echo "<td>";

                    $date = date_create( $row['entryDate']);
                    echo date_format($date, 'm/d/Y H:i');

                    echo "<br>By: ";
                    echo getFullName($row['senderID']);


                    echo "<br><br>";
                    echo $row['comment'];
                    echo "<br><br>";
                    echo "<strong>Would you recommend this service?</strong>";
                    echo "<br>";
                    isRecommended($row['recommend']);

                    echo "</td></tr>";
                }
                 if ( $stars1Comments == 0){
                    echo "No comments available";
                }

            ?>

            </table>

</div>
</div>
                        
                
                
                
                

            </div>
            </div>   

        </div>
    
</div>






<!--------- NEED TO BE ADDED TO ALL DOCUMENT FROM HERE -------->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script src="js/bootbox.js"></script>
    <script src="js/bootbox.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>


    <!-- Custom for project -->
    <script src="js/editProfileactions.js"></script>
    
     <!--Start online JSS first-->
    <script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
    <!--Bootstrap JSS-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <!--Customized JSS-->
    <script src="js/myjs.js"></script>
    
    <!--change active mode in the navbar-->

    <script> 
        $('.parent  div').hide();

$('#nav a').click(function() {
    console.log($(this).index('a'));
    var $div = $('.parent > div').eq($(this).index('#nav a'));
    $div.show();
    $('.parent > div').not($div).hide();
});


        $(".nav a").on("click", function(){
           $(".nav").find(".active").removeClass("active");
           $(this).parent().addClass("active");
        });
 /*       
        $(document)  
        .on('show.bs.modal', '.modal', function(event) {
          $(this).appendTo($('body'));
        })
        .on('shown.bs.modal', '.modal.in', function(event) {
          setModalsAndBackdropsOrder();
        })
        .on('hidden.bs.modal', '.modal', function(event) {
          setModalsAndBackdropsOrder();
        });

        function setModalsAndBackdropsOrder() {  
          var modalZIndex = 1040;
          $('.modal.in').each(function(index) {
            var $modal = $(this);
            modalZIndex++;
            $modal.css('zIndex', modalZIndex);
            $modal.next('.modal-backdrop.in').addClass('hidden').css('zIndex', modalZIndex - 1);
        });
          $('.modal.in:visible:last').focus().next('.modal-backdrop.in').removeClass('hidden');
        }
        
        $(".flip").on("click", function(e) {        
            var target = $(this).attr("href");
            $(target).slideToggle("fast");
            $(".panel").not(target).hide();

            e.preventDefault();
        });
*/
        
    </script>

    
</body>
</html>
